# Evaluation logic
def handler(event, context):

    print('hello from lambda lambda lambda')
    return {
                  "statusCode": 200,
                  "body": "Hello from Lambda! 1 2"
              }