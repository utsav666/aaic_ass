import os
import sagemaker
from sagemaker.sklearn.estimator import SKLearn
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.workflow.steps import TrainingStep

# Get values from environment or use defaults
role = os.environ["SAGEMAKER_ROLE"]
bucket = "lrl-sagemaker-models"
region = "us-east-2"
output_path = f"s3://{bucket}/output"

sagemaker_session = sagemaker.Session()

sklearn_estimator = SKLearn(
    entry_point="train.py",
    source_dir="sagemaker",
    role=role,
    instance_type="ml.m5.large",
    framework_version="0.23-1",
    output_path=output_path,
    sagemaker_session=sagemaker_session
)

train_step = TrainingStep(name="TrainLogisticRegression", estimator=sklearn_estimator)

pipeline = Pipeline(
    name="LogisticRegressionPipeline",
    steps=[train_step],
    sagemaker_session=sagemaker_session
)

pipeline.upsert(role_arn=role)
print("✅ SageMaker pipeline created/updated. Run it manually from AWS Console.")

