# Evaluation logic
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_iris
import joblib
import argparse
import os

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-dir', type=str, default=os.environ.get('SM_MODEL_DIR'))
    args = parser.parse_args()

    iris = load_iris()
    X, y = iris.data, iris.target

    model = LogisticRegression(max_iter=200)
    model.fit(X, y)

    # Save model to model-dir for SageMaker to pick up
    joblib.dump(model, os.path.join(args.model_dir, "model.joblib"))
